PollData
========

.. autoclass:: praw.models.reddit.poll.PollData
    :inherited-members:
