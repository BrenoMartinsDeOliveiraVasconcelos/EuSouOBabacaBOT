SubredditRedditorFlairTemplates
===============================

.. autoclass:: praw.models.reddit.subreddit.SubredditRedditorFlairTemplates
    :inherited-members:
