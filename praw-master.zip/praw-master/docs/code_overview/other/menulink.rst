MenuLink
========

.. autoclass:: praw.models.MenuLink
    :inherited-members:
