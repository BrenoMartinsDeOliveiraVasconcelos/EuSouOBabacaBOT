ButtonWidget
============

.. autoclass:: praw.models.ButtonWidget
    :inherited-members:
