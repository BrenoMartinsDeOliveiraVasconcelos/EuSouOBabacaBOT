SubredditQuarantine
===================

.. autoclass:: praw.models.reddit.subreddit.SubredditQuarantine
    :inherited-members:
