SubredditRelationship
=====================

.. autoclass:: praw.models.reddit.subreddit.SubredditRelationship
    :inherited-members:
