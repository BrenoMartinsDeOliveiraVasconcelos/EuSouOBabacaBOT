IDCard
======

.. autoclass:: praw.models.IDCard
    :inherited-members:
