PartialRedditor
===============

.. autoclass:: praw.models.redditors.PartialRedditor
    :inherited-members:
