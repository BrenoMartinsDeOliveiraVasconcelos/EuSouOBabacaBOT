SubredditWiki
=============

.. autoclass:: praw.models.reddit.subreddit.SubredditWiki
    :inherited-members:
