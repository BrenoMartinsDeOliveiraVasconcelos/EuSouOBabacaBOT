Collection
==========

.. autoclass:: praw.models.Collection
    :inherited-members:
