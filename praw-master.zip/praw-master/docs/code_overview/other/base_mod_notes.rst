BaseModNotes
============

.. autoclass:: praw.models.mod_notes.BaseModNotes
    :inherited-members:
