InlineGif
=========

.. autoclass:: praw.models.InlineGif
    :inherited-members:
