ModNote
=======

.. autoclass:: praw.models.ModNote
    :inherited-members:
