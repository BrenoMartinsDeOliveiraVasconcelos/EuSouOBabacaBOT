Emoji
=====

.. autoclass:: praw.models.reddit.emoji.Emoji
    :inherited-members:
