ListingGenerator
================

.. autoclass:: praw.models.ListingGenerator
    :inherited-members:
