CustomWidget
============

.. autoclass:: praw.models.CustomWidget
    :inherited-members:
