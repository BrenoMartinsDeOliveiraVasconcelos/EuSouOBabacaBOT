RulesWidget
===========

.. autoclass:: praw.models.RulesWidget
    :inherited-members:
