ModeratorsWidget
================

.. autoclass:: praw.models.ModeratorsWidget
    :inherited-members:
