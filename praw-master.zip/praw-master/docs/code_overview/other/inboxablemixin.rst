InboxableMixin
==============

.. autoclass:: praw.models.reddit.mixins.InboxableMixin
    :inherited-members:
