Rule
====

.. autoclass:: praw.models.Rule
    :inherited-members:
