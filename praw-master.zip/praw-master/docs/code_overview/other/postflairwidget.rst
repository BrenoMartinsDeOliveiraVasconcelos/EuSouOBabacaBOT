PostFlairWidget
===============

.. autoclass:: praw.models.PostFlairWidget
    :inherited-members:
