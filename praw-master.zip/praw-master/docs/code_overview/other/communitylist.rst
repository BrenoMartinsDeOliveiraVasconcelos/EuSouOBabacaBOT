CommunityList
=============

.. autoclass:: praw.models.CommunityList
    :inherited-members:
