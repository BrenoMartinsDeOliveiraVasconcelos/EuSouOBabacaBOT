DraftList
=========

.. autoclass:: praw.models.DraftList
    :inherited-members:
