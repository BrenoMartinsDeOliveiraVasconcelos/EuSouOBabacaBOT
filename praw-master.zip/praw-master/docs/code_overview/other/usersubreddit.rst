UserSubreddit
=============

.. autoclass:: praw.models.UserSubreddit
    :inherited-members:
