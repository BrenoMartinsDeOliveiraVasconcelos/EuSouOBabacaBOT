ModNoteMixin
============

.. autoclass:: praw.models.reddit.mixins.ModNoteMixin
    :members:
