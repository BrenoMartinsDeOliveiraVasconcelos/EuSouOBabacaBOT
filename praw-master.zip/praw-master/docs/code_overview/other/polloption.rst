PollOption
==========

.. autoclass:: praw.models.reddit.poll.PollOption
    :inherited-members:
