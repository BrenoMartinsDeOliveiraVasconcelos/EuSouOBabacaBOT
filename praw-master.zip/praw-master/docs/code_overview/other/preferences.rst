Preferences
===========

.. autoclass:: praw.models.Preferences
    :inherited-members:
