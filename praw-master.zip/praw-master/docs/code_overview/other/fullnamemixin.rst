FullnameMixin
=============

.. autoclass:: praw.models.reddit.mixins.FullnameMixin
    :inherited-members:
