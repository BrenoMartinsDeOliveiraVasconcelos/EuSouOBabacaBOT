Widget
======

.. autoclass:: praw.models.Widget
    :inherited-members:
