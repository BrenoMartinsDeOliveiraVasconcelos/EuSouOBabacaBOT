TextArea
========

.. autoclass:: praw.models.TextArea
    :inherited-members:
