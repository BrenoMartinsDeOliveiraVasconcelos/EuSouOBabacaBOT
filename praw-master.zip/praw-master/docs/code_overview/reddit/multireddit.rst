reddit.multireddit
==================

.. autoclass:: praw.models.MultiredditHelper
    :inherited-members:
