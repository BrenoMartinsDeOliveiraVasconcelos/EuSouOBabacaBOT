reddit.subreddits
=================

.. autoclass:: praw.models.Subreddits
    :inherited-members:
