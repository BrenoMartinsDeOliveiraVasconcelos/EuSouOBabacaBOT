Comment
=======

.. autoclass:: praw.models.Comment
    :inherited-members:
