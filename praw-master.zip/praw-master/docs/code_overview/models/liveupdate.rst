LiveUpdate
==========

.. autoclass:: praw.models.LiveUpdate
    :inherited-members:
