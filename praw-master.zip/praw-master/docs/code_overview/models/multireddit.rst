Multireddit
===========

.. autoclass:: praw.models.Multireddit
    :inherited-members:
