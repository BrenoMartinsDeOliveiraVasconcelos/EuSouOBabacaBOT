ModmailConversation
===================

.. autoclass:: praw.models.reddit.modmail.ModmailConversation
    :inherited-members:
