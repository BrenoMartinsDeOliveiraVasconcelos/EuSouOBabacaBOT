# Security Policy

## Supported Versions

The supported versions of PRAW include the previous major release. 
This means that if PRAW is on 6.5.0, PRAW versions 5.0.0 and greater are supported.

## Reporting a Vulnerability

Contact Bryce Boe (bbzbryce@gmail.com) as soon as possible to address
the vulnerability.
